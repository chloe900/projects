import java.util.*;
public class Node {
	Node parent;
	int col;
	int row;
	
	//distance between current node and the start node
	int gcost;
	//sum of g cost and h cost
	int fcost;
	//distance between current and goal
	int hcost;
	
	boolean start;
	boolean goal;
	boolean solid;
	boolean open;
	boolean checked;
	
	public Node(int col, int row) {
		this.col = col;
		this.row = row;
	}
	
	public void setAsStart() {
		start = true;
	}
	
	public void setAsGoal() {
		goal = true;
	}
	
	public void setAsSolid() {
		solid = true;
	}
	
	public void setAsOpen() {
		open = true;
	}
	
	public void setAsChecked() {
		
		checked = true;
	}
	
	public void setAsPath() {
		
	}
}
