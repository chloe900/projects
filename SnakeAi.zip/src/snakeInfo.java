import java.util.*;

public class snakeInfo {
	 	int headX, headY;
	    int length;
	    ArrayList<Node> body;

	    public snakeInfo(int headX, int headY, int length) {
	        this.headX = headX;
	        this.headY = headY;
	        this.length = length;
	        this.body = new ArrayList<>();
	    }
}


