import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

import za.ac.wits.snake.DevelopmentAgent;
public class MyAgent extends DevelopmentAgent {
	
	Node[][] node = new Node[50][50];
	
	Node startNode, currentNode, goalNode;
	ArrayList<Node> openList = new ArrayList<>();
	ArrayList<Node> checkedList = new ArrayList<>();
	ArrayList<snakeInfo> otherSnakes = new ArrayList<>();

	
	boolean goalReached = false;
	int step = 0;
	
	
	

    public static void main(String args[]) {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
    	 for (int col = 0; col < 50; col++) {
             for (int row = 0; row < 50; row++) {
                 node[col][row] = new Node(col, row);
                 //if()
             }
         }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);
            int maxCols = Integer.parseInt(temp[1]);
            int maxRows = Integer.parseInt(temp[2]);
            
           

            // Initialize the node array
            Node[][] node = new Node[maxCols][maxRows];

            // Populate the node array with Node instances
            for (int col = 0; col < maxCols; col++) {
                for (int row = 0; row < maxRows; row++) {
                    node[col][row] = new Node(col, row);
                }
            }


            while (true) {
            	
            	
            	
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }
                

                // Parse the apple's position from the input string
                String[] appleCoordinates = line.split(" ");
                int appleX = Integer.parseInt(appleCoordinates[0]);
                int appleY = Integer.parseInt(appleCoordinates[1]);

                // Read and process obstacle information (if needed)
                int numObstacles = 3;
                Node[][] obstacles = new Node[3][];

                // Initialize the grid and obstacles here
                for (int j = 0; j < numObstacles; j++) {
                    String obsLine = br.readLine();
                    String[] coords = obsLine.split(" ");
                    obstacles[j] = new Node[coords.length];
                    
                    for (int i = 0; i < coords.length; i++) {
                        String[] xy = coords[i].split(",");
                        int x = Integer.parseInt(xy[0]);
                        int y = Integer.parseInt(xy[1]);
                        // Create and initialize obstacle nodes
                        obstacles[j][i] = node[x][y];
                        setSolidNode(x, y);
                       
                    }
                }


                int mySnakeNum = Integer.parseInt(br.readLine());
                for (int i = 0; i <nSnakes; i++) {
                    String snakeLine = br.readLine();
                    

                    // Parse and process information about each snake
                    String[] snakeInfo = snakeLine.split(" ");
                    //dead or alive
                    String status = snakeInfo[0];
                    
                    //int snakeLength = Integer.parseInt(snakeInfo[1]);
                    //int snakeKills = Integer.parseInt(snakeInfo[2]);

                    // Parse the snake's head position
                    if (status.equals("alive")) {
                        String[] snakeCoordinates = snakeInfo[3].split(",");
                        int headX = Integer.parseInt(snakeCoordinates[0]);
                        int headY = Integer.parseInt(snakeCoordinates[1]);
                    

                    // Check if the current snake is your snake (mySnakeNum)
                    if (i == mySnakeNum) {
                        setStartNode(headX, headY);
                        setGoalNode(appleX, appleY);
                       
                        autoSearch();
                        trackPath(); // Track the path found by A*

                        int move = getNextMove();
                        System.err.println(move);
                        System.out.println(move);
                       
                    }
                    
                    if (i != mySnakeNum) {
                    
                        String[] theseSnakes = snakeLine.split(" ");
                        String[] snakeStuff = theseSnakes[3].split(",");
                        snakeInfo otherSnake = new snakeInfo(Integer.parseInt(snakeStuff[0]), Integer.parseInt(snakeStuff[1]), Integer.parseInt(theseSnakes[1]) );

                        // Check if the snake is alive (ignore dead snakes)
                        if (theseSnakes[0].equals("alive")) {
                           
                           //adding body parts to the snake's body
                            String[] bodyCoordinates = Arrays.copyOfRange(theseSnakes, 3, theseSnakes.length);
                            System.err.println("Body Coordinates: " + Arrays.toString(bodyCoordinates));
                            for (String bodyCoordinate : bodyCoordinates) {
                                String[] things = bodyCoordinate.split(",");
                                int bodyX = Integer.parseInt(things[0]);
                                int bodyY = Integer.parseInt(things[1]);
                                otherSnake.body.add(node[bodyX][bodyY]);
                                //setSolidNode(bodyX, bodyY);
                            }

                            otherSnakes.add(otherSnake);
                        }
                    }
                  
                      
                    }
                    
                }
                // Process other snakes' information if needed
                
                for (snakeInfo snake : otherSnakes) {
                    // Check if the snake has moved
                    int newHeadX = snake.headX;
                    int newHeadY = snake.headY;

                    // Remove the old head position from solid nodes (if it's no longer part of the body)
                    if (node[newHeadX][newHeadY].solid) {
                        node[newHeadX][newHeadY].setAsOpen();
                    }

                    // Mark the new head position as a solid node
                    node[newHeadX][newHeadY].setAsSolid();
                }
                
               
            }
            // Finished reading, calculate move (if not already calculated)
            

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        
    private int getNextMove() {
       
        Node bestNode = null;
        int bestCost = Integer.MAX_VALUE;

        
        for (Node neighbor : getNeighbors(currentNode)) {
            int cost = getCost(neighbor);
            //System.err.println("f cost" + " " + cost);

            if (cost < bestCost) {
                bestNode = neighbor;
                bestCost = cost;
            }
        }
        
        if (bestNode != null) {
            if (bestNode.col < currentNode.col) {
                return 2; 
            } else if (bestNode.col > currentNode.col) {
                return 3; 
            } else if (bestNode.row < currentNode.row) {
                return 0; 
            } else if (bestNode.row > currentNode.row) {
                return 1; 
            }
        }
        System.err.println(bestNode.toString());

               return 0; 
    }

        
        public void setStartNode(int col, int row) {
    		node[col][row].setAsStart();
    		startNode = node[col][row];
    		currentNode = startNode;
    		System.err.println("Start Node: col=" + col + ", row=" + row);
    	}
    	
    	public void setGoalNode(int col, int row) {
    		node[col][row].setAsGoal();
    		goalNode = node[col][row];
    		System.err.println("Goal Node: col=" + col + ", row=" + row);
    	}
    	
    	public void setSolidNode(int col, int row) {
    		node[col][row].setAsSolid();
    	}
    	
    	
    	private int getCost(Node node) {
    		//g
    		int x = Math.abs(node.col - startNode.col);
    		int y = Math.abs(node.row - startNode.row);
    		node.gcost = x + y;
    		
    		//h
    		x = Math.abs(node.col - goalNode.col);
    		y = Math.abs(node.row - goalNode.row);
    		node.hcost = x + y;
    		
    		//f
    		node.fcost = node.gcost + node.hcost;
    		
    		
    		return node.fcost;
    		
    		
    	}
    	
    	
    	
    	private void openNode(Node node) {
    		if (!node.open && !node.checked && !node.solid) {
    		    
    			node.setAsOpen();
    			node.parent = currentNode;
    			openList.add(node);
    		}
    	}
    	
    	private void trackPath() {
    	    Node current = goalNode;

    	    while (current != null && current != startNode) {
    	        current.setAsPath();
    	        if (current.parent != null) {
    	            current = current.parent;
    	        } else {
    	           //when currentNode is null
    	            break; 
    	        }
    	    }
    	    
    	   System.err.println(current.toString());
    	}
    	
    	private ArrayList<Node> getNeighbors(Node currentNode) {
    	    ArrayList<Node> neighbors = new ArrayList<>();

    	    int col = currentNode.col;
    	    int row = currentNode.row;

    	    // Check left neighbor
    	    if (col > 0 && !node[col - 1][row].solid) {
    	        neighbors.add(node[col - 1][row]);
    	    }

    	    // Check right neighbor
    	    if (col < 49 && !node[col + 1][row].solid) {
    	        neighbors.add(node[col + 1][row]);
    	    }

    	    // Check up neighbor
    	    if (row > 0 && !node[col][row - 1].solid) {
    	        neighbors.add(node[col][row - 1]);
    	    }

    	    // Check down neighbor
    	    if (row < 49 && !node[col][row + 1].solid) {
    	        neighbors.add(node[col][row + 1]);
    	    }

    	    //trying to avoid the edge 
    	    int edgePenalty = 10; 
    	    if (col <= 10 || col >= 39) {
    	        for (Node neighbor : neighbors) {
    	            neighbor.fcost += edgePenalty;
    	        }
    	    }
    	    if (row <= 10 || row >= 39) {
    	        for (Node neighbor : neighbors) {
    	            neighbor.fcost += edgePenalty;
    	        }
    	    }

    	    return neighbors;
    	}

    	public void autoSearch() {
    	   
    	    
    	    while (!goalReached && !openList.isEmpty()) {
    	        
    	        int col = currentNode.col;
    	        int row = currentNode.row;
    	        
    	        currentNode.setAsChecked();
    	        if (!currentNode.checked && !currentNode.solid) {
    	            checkedList.add(currentNode);
    	        }
    	        openList.remove(currentNode);
    	        
    	        
    	        if (row - 1 >= 0) {
    	            openNode(node[col][row - 1]);
    	        }
    	        if (col - 1 >= 0) {
    	            openNode(node[col - 1][row]);
    	        }
    	        if (row + 1 < 50) {
    	            openNode(node[col][row + 1]);
    	        }
    	        if (col + 1 < 50) {
    	            openNode(node[col + 1][row]);
    	        }
    	        
    	        int bestNode = 0;
    	        int bestNodeFcost = 999;
    	        
    	        for (int i = 0; i < openList.size(); i++) {
    	            if (openList.get(i).fcost < bestNodeFcost) {
    	                bestNode = i;
    	                bestNodeFcost = openList.get(i).fcost;
    	            }
    	            
    	            //if fcost is equal, use gcost
    	            else if (openList.get(i).fcost == bestNodeFcost) {
    	                if (openList.get(i).gcost < openList.get(bestNode).gcost) {
    	                    bestNode = i;
    	                }
    	            }
    	        }
    	        
    	        currentNode = openList.get(bestNode);
    	        
    	        if (currentNode == goalNode) {
    	            goalReached = true;
    	        }
    	        
    	    }
    	    //step++;
    	}
    	
    	
    	
    	

    	
}	

